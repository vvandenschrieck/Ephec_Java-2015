package tri1ArrayMap;

public class GarsAvant {
	
	private String nom;
	private String niss;
	private double taille;
		
	

	@Override
	public String toString() {
		return "Gars [nom=" + nom + ", niss=" + niss + ", taille=" + taille + "]";
	}


	public String getNom() {
		return nom;
	}


	public String getNiss() {
		return niss;
	}


	public double getTaille() {
		return taille;
	}
	
	


}