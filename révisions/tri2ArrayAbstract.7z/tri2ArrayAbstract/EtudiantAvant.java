package tri2ArrayAbstract;

public class EtudiantAvant extends Personne{
	
	public final static double TAX = 0.06;
	private double salaire;
	
	
}

